#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
os.chdir("C:/Users/130901/Desktop/Assignment/Internship")


# In[7]:


xls = pd.ExcelFile("TakenMind-Python-Analytics-Problem-case-study-1-1.xlsx")


# In[8]:


Existing_employees = pd.read_excel(xls,'Existing employees')


# In[9]:


Employees_left = pd.read_excel(xls,'Employees who have left')


# In[10]:


print(Existing_employees.columns.values)


# In[11]:


print(Employees_left.columns.values)


# In[12]:


Existing_employees.isnull().sum()


# In[13]:


Employees_left.isnull().sum()


# In[15]:


Existing_employees.shape


# In[16]:


Employees_left.shape


# In[17]:


Existing_employees.dtypes


# In[44]:


Existing_employees['Left'] = 0


# In[45]:


Employees_left['Left'] = 1


# In[46]:


combine = pd.concat([Existing_employees,Employees_left])


# In[47]:


print(combine.columns.values)


# In[48]:


print(combine.shape)


# In[49]:


combine = combine.drop('Emp ID',axis = 1)


# In[50]:


combine.groupby('Left').mean()


# In[51]:


correlation = combine.corr()
import seaborn as sns
fig, ax = plt.subplots(figsize=(20, 10))
sns.heatmap(correlation,annot = True,ax = ax)
plt.savefig('Correlation Matrix.png')
#From the heatmap, there is a positive(+) correlation between projectCount, averageMonthlyHours, and evaluation. 
#Which could mean that the employees who spent more hours and did more projects were evaluated highly.

#For the negative(-) relationships, turnover and satisfaction are highly correlated. 
#I'm assuming that people tend to leave a company more when they are less satisfied


# In[59]:


Employee_working = combine['satisfaction_level'][combine['Left']== 0].mean()


# In[60]:


EmployeeLeft = combine['satisfaction_level'][combine['Left']== 1].mean()


# In[62]:


print('Employees who left the company have statisfaction level  ' + str(EmployeeLeft))
print('Employees who working in company have statisfaction level  ' + str(Employee_working))


# In[65]:


print(combine.columns.values)


# In[67]:


sns.distplot(combine.satisfaction_level,kde = False,color = 'g').set_title('Statisfaction Level of the Employee')
plt.savefig('Satisfaction.png')


# In[70]:


sns.distplot(combine.last_evaluation,kde = False,color = 'r').set_title('Evaluation of Employees')
plt.savefig('LastEvaluation.png')


# In[72]:


sns.distplot(combine.average_montly_hours,kde = False,color = 'blue').set_title('Average Monthly hours')
plt.savefig('average_montly_hours.png')


# In[75]:


print(combine.columns.values)


# In[76]:


sns.countplot(y = 'salary',hue = 'Left',data = combine)
plt.title('Count the salary')
plt.savefig('salary.png')


# In[82]:


fig, ax = plt.subplots(figsize=(20, 10))
sns.countplot(x = 'dept',data = combine)
plt.title('Distribution According to the depatement')
plt.savefig('Depatement.png')


# In[84]:


fig,ax = plt.subplots(figsize = (20,10))
sns.countplot(y = 'dept',hue = 'Left',data = combine)
plt.title('Ration of people left according to the dept')
plt.savefig('Depatwise.png')


# In[89]:


sns.countplot(y ='number_project',hue = 'Left',data = combine)
plt.title('Number of project Relationship People woho leave company')
plt.savefig('NumberProject.png')


# In[95]:


sns.kdeplot(combine.loc[(combine['Left'] == 0),'last_evaluation'],color = 'r',label = "Working Employes")
sns.kdeplot(combine.loc[(combine['Left'] == 1),'last_evaluation'],color = 'b',label = "Non Working Employees")
plt.title("Employee Evaluation Distribution - Working V.S. No working Employees")
plt.savefig("Employee evaluation")


# In[96]:


print(combine.columns.values)


# In[101]:


sns.kdeplot(combine.loc[(combine['Left'] == 0),'average_montly_hours'],color = 'r',label = 'woking Employees')
sns.kdeplot(combine.loc[(combine['Left'] == 1),'average_montly_hours'],color = 'b',label = 'Left Employees')
plt.title('Employee AverageMonthly Hours Distribution - working V.S. Left employee')
plt.savefig('AverageMonthly Hours.png')


# In[102]:


print(combine.columns)


# In[106]:


sns.kdeplot(combine.loc[(combine['Left'] == 0),'satisfaction_level'],color = 'r',label = 'Working Employees')
sns.kdeplot(combine.loc[(combine['Left'] == 1),'satisfaction_level'],color = 'b',label = 'Left Company')
plt.title('Satisfaction level/Employee Left vs working Employees')
plt.savefig('Satisfaction_level.png')


# In[107]:


print(combine.columns.values)


# In[110]:


sns.boxplot(x = 'number_project',y = 'average_montly_hours',hue = 'Left',data = combine)
plt.savefig('ProjectCount_Hours.png')


# In[112]:


sns.boxplot(x = 'number_project',y = 'last_evaluation',hue = 'Left',data = combine)
plt.savefig('ProjectCount_Evaluation.png')


# In[114]:


print(combine.columns.values)


# In[118]:


sns.lmplot(x = 'satisfaction_level' , y ='last_evaluation',data = combine,hue = 'Left',fit_reg = False)
plt.savefig('Satisfaction_Last.png')


# In[119]:


print(combine.columns.values)


# In[120]:


sns.countplot(y ='time_spend_company',hue = 'Left',data = combine)
plt.savefig('Time_spendcompanu.png')


# In[121]:


sns.countplot(y = 'promotion_last_5years' ,hue = 'Left',data= combine)


# In[125]:


print(combine['promotion_last_5years'].nunique())


# In[ ]:




